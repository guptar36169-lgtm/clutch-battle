import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.clutcharena.tournaments',
  appName: 'ClutchArena',
  webDir: 'www'
};

export default config;
