package com.clutcharena.tournaments;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
