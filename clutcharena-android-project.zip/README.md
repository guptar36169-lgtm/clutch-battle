# ClutchArena — Android project (Capacitor)

Ye poora Android Studio project hai, ready to build. Isse APK banane ke liye:

## Requirements (apne computer par install karo)
- Node.js (LTS)
- Android Studio (Android SDK khud install kar deta hai)
- JDK 17

## Steps
1. Is folder ko unzip karke terminal mein andar jao:
   cd clutcharena-android
2. Dependencies install karo:
   npm install
3. Android project sync karo:
   npx cap sync android
4. Android Studio mein kholo:
   npx cap open android
5. Android Studio mein: Build → Build Bundle(s)/APK(s) → Build APK(s)
6. Build complete hone par 'locate' link se app-debug.apk mil jayegi.

## App ka web content update karna ho to
`www/index.html` file hi poora app hai — usme koi bhi change karke phir se
`npx cap sync android` chalao aur dubara build karo.

## Note
Ye ek DEBUG build banayega — apne phone par install karke turant test kar sakte ho.
Play Store par daalne ke liye ise "release" build banake sign karna padega
(alag topic — bata dena agar wo bhi chahiye).
